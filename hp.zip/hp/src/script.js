// HTML bodyの背景色をマウスの位置に基づいて変更する関数
function changeBackgroundColor(event) {
    // ビューポートの幅と高さを取得
    const vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
    const vh = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);

    // マウスの位置に基づいて色を計算（赤と青を使用）
    const red = Math.round((event.clientX / vw) * 255);
    const blue = Math.round((event.clientY / vh) * 255);

    // 背景色を設定
    document.body.style.backgroundColor = `rgb(${red}, 0, ${blue})`;
}

// マウスが動くたびに背景色を変更するイベントリスナーを追加
document.addEventListener('mousemove', changeBackgroundColor);

// タイピングエフェクトを表示する関数
function typingEffect(element, text, delay = 100) {
    let i = 0;
    function type() {
        if (i < text.length) {
            // 現在のテキストに次の文字を追加
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(type, delay); // 次の文字を遅延して表示
        }
    }
    type(); // タイピング開始
}

